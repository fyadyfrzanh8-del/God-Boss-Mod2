package com.godboss.client;

import com.godboss.GodBossMod;
import com.godboss.entity.GodBossEntity;
import net.minecraft.client.model.EntityModel;
import net.minecraft.client.model.geom.ModelLayerLocation;
import net.minecraft.client.model.geom.ModelPart;
import net.minecraft.client.model.geom.PartPose;
import net.minecraft.client.model.geom.builders.*;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.client.renderer.entity.MobRenderer;
import net.minecraft.resources.ResourceLocation;

public class GodBossRenderer extends MobRenderer<GodBossEntity, GodBossRenderer.Model> {
    public static final ModelLayerLocation LAYER_LOCATION =
            new ModelLayerLocation(new ResourceLocation(GodBossMod.MODID, "god_boss"), "main");
    private static final ResourceLocation TEXTURE =
            new ResourceLocation(GodBossMod.MODID, "textures/entity/god_boss.png");

    public GodBossRenderer(EntityRendererProvider.Context context) {
        super(context, new Model(context.bakeLayer(LAYER_LOCATION)), 2.0F);
    }

    public static LayerDefinition createBodyLayer() {
        MeshDefinition mesh = new MeshDefinition();
        PartDefinition root = mesh.getRoot();
        root.addOrReplaceChild("body", CubeListBuilder.create()
                .texOffs(0, 0).addBox(-8, -12, -4, 16, 24, 8), PartPose.offset(0, 0, 0));
        root.addOrReplaceChild("head", CubeListBuilder.create()
                .texOffs(0, 32).addBox(-6, -8, -6, 12, 12, 12)
                .texOffs(48, 32).addBox(-4, -3, -6.5F, 2, 2, 1)
                .texOffs(48, 32).addBox(2, -3, -6.5F, 2, 2, 1), PartPose.offset(0, -14, 0));
        root.addOrReplaceChild("left_arm", CubeListBuilder.create()
                .texOffs(32, 0).addBox(-3, -2, -3, 6, 22, 6), PartPose.offset(11, -8, 0));
        root.addOrReplaceChild("right_arm", CubeListBuilder.create()
                .texOffs(32, 0).addBox(-3, -2, -3, 6, 22, 6), PartPose.offset(-11, -8, 0));
        root.addOrReplaceChild("left_leg", CubeListBuilder.create()
                .texOffs(56, 0).addBox(-4, 0, -4, 8, 22, 8), PartPose.offset(5, 12, 0));
        root.addOrReplaceChild("right_leg", CubeListBuilder.create()
                .texOffs(56, 0).addBox(-4, 0, -4, 8, 22, 8), PartPose.offset(-5, 12, 0));
        root.addOrReplaceChild("left_wing", CubeListBuilder.create()
                .texOffs(0, 52).addBox(0, -2, 0, 2, 4, 34), PartPose.offset(7, -10, 3));
        root.addOrReplaceChild("right_wing", CubeListBuilder.create()
                .texOffs(0, 52).addBox(-2, -2, 0, 2, 4, 34), PartPose.offset(-7, -10, 3));
        // Twin purple ninja blades are modeled into the hands; custom texture supplies purple glow.
        root.addOrReplaceChild("left_blade", CubeListBuilder.create()
                .texOffs(0, 92).addBox(-1, -2, -1, 2, 24, 2), PartPose.offset(11, 12, -1));
        root.addOrReplaceChild("right_blade", CubeListBuilder.create()
                .texOffs(0, 92).addBox(-1, -2, -1, 2, 24, 2), PartPose.offset(-11, 12, -1));
        return LayerDefinition.create(mesh, 128, 128);
    }

    @Override
    public ResourceLocation getTextureLocation(GodBossEntity entity) { return TEXTURE; }

    public static class Model extends EntityModel<GodBossEntity> {
        private final ModelPart root;
        private final ModelPart leftWing;
        private final ModelPart rightWing;
        public Model(ModelPart root) {
            this.root = root;
            this.leftWing = root.getChild("left_wing");
            this.rightWing = root.getChild("right_wing");
        }
        @Override
        public void setupAnim(GodBossEntity entity, float limbSwing, float limbSwingAmount,
                              float ageInTicks, float netHeadYaw, float headPitch) {
            float flap = (float)Math.sin(ageInTicks * 0.35F) * 0.45F;
            leftWing.yRot = flap;
            rightWing.yRot = -flap;
        }
        @Override
        public void renderToBuffer(com.mojang.blaze3d.vertex.PoseStack poseStack,
                                   com.mojang.blaze3d.vertex.VertexConsumer buffer,
                                   int packedLight, int packedOverlay, float red, float green,
                                   float blue, float alpha) {
            root.render(poseStack, buffer, packedLight, packedOverlay, red, green, blue, alpha);
        }
    }
}
