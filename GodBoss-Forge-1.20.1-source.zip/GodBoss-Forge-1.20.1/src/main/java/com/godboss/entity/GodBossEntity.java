package com.godboss.entity;

import com.godboss.GodBossMod;
import net.minecraft.core.BlockPos;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.syncher.EntityDataAccessor;
import net.minecraft.network.syncher.EntityDataSerializers;
import net.minecraft.network.syncher.SynchedEntityData;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.*;
import net.minecraft.world.entity.ai.attributes.AttributeSupplier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.ai.control.FlyingMoveControl;
import net.minecraft.world.entity.ai.goal.*;
import net.minecraft.world.entity.ai.navigation.FlyingPathNavigation;
import net.minecraft.world.entity.ai.navigation.PathNavigation;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.item.enchantment.Enchantments;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.Vec3;
import net.minecraft.world.entity.item.ItemEntity;
import net.minecraft.world.damagesource.DamageTypes;
import net.minecraft.tags.DamageTypeTags;
import net.minecraft.world.entity.projectile.Projectile;
import net.minecraft.world.entity.monster.Monster;

import java.util.List;

public class GodBossEntity extends Monster {
    private static final EntityDataAccessor<Integer> PHASE =
            SynchedEntityData.defineId(GodBossEntity.class, EntityDataSerializers.INT);
    private static final EntityDataAccessor<Boolean> FLYING =
            SynchedEntityData.defineId(GodBossEntity.class, EntityDataSerializers.BOOLEAN);
    private int blindnessClock = 0;
    private int bladeClock = 0;
    private int activeBlindnessTicks = 0;
    private int armorTier = 0;
    private boolean phase100ExplosionDone = false;
    private boolean deathExplosionDone = false;
    private boolean rewardsDropped = false;
    private int flightClock = 0;

    public GodBossEntity(EntityType<? extends Monster> type, Level level) {
        super(type, level);
        this.moveControl = new FlyingMoveControl(this, 20, true);
        this.xpReward = 500;
        this.setPersistenceRequired();
    }

    public static AttributeSupplier.Builder createAttributes() {
        return Monster.createMonsterAttributes()
                .add(Attributes.MAX_HEALTH, 1200.0D)
                .add(Attributes.MOVEMENT_SPEED, 0.34D)
                .add(Attributes.FLYING_SPEED, 0.45D)
                .add(Attributes.ATTACK_DAMAGE, 4.0D)
                .add(Attributes.ARMOR, 20.0D)
                .add(Attributes.ARMOR_TOUGHNESS, 12.0D)
                .add(Attributes.KNOCKBACK_RESISTANCE, 1.0D)
                .add(Attributes.FOLLOW_RANGE, 64.0D);
    }

    @Override
    protected void defineSynchedData() {
        super.defineSynchedData();
        this.entityData.define(PHASE, 1);
        this.entityData.define(FLYING, false);
    }

    @Override
    protected void registerGoals() {
        this.goalSelector.addGoal(0, new FloatGoal(this));
        this.goalSelector.addGoal(1, new MeleeAttackGoal(this, 1.15D, true));
        this.goalSelector.addGoal(2, new WaterAvoidingRandomStrollGoal(this, 0.8D));
        this.goalSelector.addGoal(3, new LookAtPlayerGoal(this, Player.class, 32.0F));
        this.goalSelector.addGoal(4, new RandomLookAroundGoal(this));
        this.targetSelector.addGoal(1, new HurtByTargetGoal(this));
        this.targetSelector.addGoal(2, new NearestAttackableTargetGoal<>(this, Player.class, true));
    }

    @Override
    protected PathNavigation createNavigation(Level level) {
        return new FlyingPathNavigation(this, level);
    }

    @Override
    public void tick() {
        super.tick();
        if (this.level().isClientSide) return;

        double hearts = this.getHealth() / 2.0D;
        updatePhaseAndArmor(hearts);

        // Fly periodically, never more than about 10 blocks above the target/ground.
        LivingEntity target = this.getTarget();
        if (target != null && target.isAlive()) {
            flightClock++;
            if (flightClock % 160 < 80) {
                this.entityData.set(FLYING, true);
                double desiredY = Math.min(target.getY() + 8.0D, this.level().getMaxBuildHeight() - 2);
                if (this.getY() < desiredY - 1.0D) {
                    this.getMoveControl().setWantedPosition(target.getX(), desiredY, target.getZ(), 1.0D);
                } else {
                    this.getMoveControl().setWantedPosition(target.getX(), target.getY() + 2.0D, target.getZ(), 0.9D);
                }
            } else {
                this.entityData.set(FLYING, false);
            }
        }

        // Blindness: every 10 seconds for 5 seconds. Reapplied during the active window,
        // so drinking milk cannot permanently remove this boss-applied effect.
        blindnessClock++;
        if (blindnessClock >= 200) {
            blindnessClock = 0;
            activeBlindnessTicks = 100;
        }
        if (activeBlindnessTicks > 0) {
            activeBlindnessTicks--;
            for (Player player : this.level().getEntitiesOfClass(Player.class, this.getBoundingBox().inflate(24.0D))) {
                player.addEffect(new MobEffectInstance(MobEffects.BLINDNESS, 3, 0, true, false, true));
            }
        }

        // At 100 hearts: one damage-only blast equivalent to 50 TNT.
        if (hearts <= 100.0D && !phase100ExplosionDone) {
            phase100ExplosionDone = true;
            damageOnlyBlast(16.0D, 100.0D, this);
        }
    }

    private void updatePhaseAndArmor(double hearts) {
        int phase = hearts > 500 ? 1 : (hearts > 200 ? 2 : 3);
        this.entityData.set(PHASE, phase);

        // Each threshold upgrades the hidden full Netherite armor exactly once.
        if (hearts <= 500 && armorTier < 1) equipHiddenArmor(6, 1);
        if (hearts <= 400 && armorTier < 2) equipHiddenArmor(10, 2);
        if (hearts <= 100 && armorTier < 3) equipHiddenArmor(120, 3);
        if (hearts <= 10 && armorTier < 4) equipHiddenArmor(255, 4);
    }

    private void equipHiddenArmor(int protection, int tier) {
        ItemStack helmet = new ItemStack(Items.NETHERITE_HELMET);
        ItemStack chest = new ItemStack(Items.NETHERITE_CHESTPLATE);
        ItemStack legs = new ItemStack(Items.NETHERITE_LEGGINGS);
        ItemStack boots = new ItemStack(Items.NETHERITE_BOOTS);
        for (ItemStack stack : List.of(helmet, chest, legs, boots)) {
            stack.enchant(Enchantments.ALL_DAMAGE_PROTECTION, protection);
        }
        this.setItemSlot(EquipmentSlot.HEAD, helmet);
        this.setItemSlot(EquipmentSlot.CHEST, chest);
        this.setItemSlot(EquipmentSlot.LEGS, legs);
        this.setItemSlot(EquipmentSlot.FEET, boots);
        this.armorTier = tier;
    }

    @Override
    public boolean hurt(DamageSource source, float amount) {
        if (source.is(DamageTypes.LAVA) || source.is(DamageTypeTags.IS_FIRE)) return false;
        Entity direct = source.getDirectEntity();
        Entity attacker = source.getEntity();
        if (direct instanceof net.minecraft.world.entity.projectile.AbstractArrow arrow) {
            // Power V arrows have a boosted base damage (vanilla base 2 + 2.5 per Power level).
            // Normal arrows and bows below Power V are rejected.
            return arrow.getBaseDamage() >= 14.4D && super.hurt(source, amount);
        }
        if (direct instanceof Projectile) return false;
        if (source.is(DamageTypeTags.IS_PROJECTILE)) return false;
        if (attacker instanceof Player) return super.hurt(source, amount);
        return super.hurt(source, amount);
    }

    @Override
    public boolean doHurtTarget(Entity target) {
        float damage = switch (this.entityData.get(PHASE)) {
            case 1 -> 4.0F;
            case 2 -> 8.0F;
            default -> 12.0F;
        };
        boolean hit = target.hurt(this.damageSources().mobAttack(this), damage);
        if (hit && target instanceof LivingEntity living) {
            if (this.entityData.get(PHASE) == 2) {
                living.addEffect(new MobEffectInstance(MobEffects.POISON, 100, 0));
            } else if (this.entityData.get(PHASE) == 3) {
                living.setSecondsOnFire(5);
            }
        }
        return hit;
    }

    private void damageOnlyBlast(double radius, double damage, Entity source) {
        for (LivingEntity entity : this.level().getEntitiesOfClass(LivingEntity.class, this.getBoundingBox().inflate(radius))) {
            if (entity == this || entity.isAlliedTo(this)) continue;
            double distance = entity.distanceTo(this);
            if (distance <= radius) {
                double scale = 1.0D - (distance / radius);
                float dealt = (float)(damage * (0.25D + 0.75D * scale));
                entity.hurt(this.damageSources().explosion(this, this), dealt);
                Vec3 push = entity.position().subtract(this.position()).normalize().scale(1.5D * scale);
                entity.push(push.x, 0.5D * scale, push.z);
            }
        }
    }

    @Override
    public void die(DamageSource source) {
        if (!this.level().isClientSide && !deathExplosionDone) {
            deathExplosionDone = true;
            damageOnlyBlast(24.0D, 200.0D, this);
        }
        super.die(source);
    }

    @Override
    protected void dropCustomDeathLoot(DamageSource source, int looting, boolean recentlyHit) {
        super.dropCustomDeathLoot(source, looting, recentlyHit);
        if (this.level().isClientSide || rewardsDropped) return;
        rewardsDropped = true;
        spawnDrop(new ItemStack(Items.NETHERITE_INGOT, 64));
        spawnDrop(new ItemStack(Items.NETHERITE_INGOT, 36));
        spawnDrop(new ItemStack(Items.DIAMOND, 50));
        ItemStack sword = new ItemStack(Items.NETHERITE_SWORD);
        sword.enchant(Enchantments.SHARPNESS, 255);
        spawnDrop(sword);
        spawnDrop(new ItemStack(Items.ELYTRA));
    }

    private void spawnDrop(ItemStack stack) {
        ItemEntity item = new ItemEntity(this.level(), this.getX(), this.getY() + 1.0D, this.getZ(), stack);
        item.setDefaultPickUpDelay();
        this.level().addFreshEntity(item);
    }

    @Override
    public boolean fireImmune() { return true; }

    @Override
    public void addAdditionalSaveData(CompoundTag tag) {
        super.addAdditionalSaveData(tag);
        tag.putInt("ArmorTier", armorTier);
        tag.putBoolean("Phase100ExplosionDone", phase100ExplosionDone);
        tag.putBoolean("DeathExplosionDone", deathExplosionDone);
        tag.putBoolean("RewardsDropped", rewardsDropped);
        tag.putInt("BlindnessClock", blindnessClock);
        tag.putInt("ActiveBlindnessTicks", activeBlindnessTicks);
        tag.putInt("BladeClock", bladeClock);
        tag.putInt("FlightClock", flightClock);
    }

    @Override
    public void readAdditionalSaveData(CompoundTag tag) {
        super.readAdditionalSaveData(tag);
        armorTier = tag.getInt("ArmorTier");
        phase100ExplosionDone = tag.getBoolean("Phase100ExplosionDone");
        deathExplosionDone = tag.getBoolean("DeathExplosionDone");
        rewardsDropped = tag.getBoolean("RewardsDropped");
        blindnessClock = tag.getInt("BlindnessClock");
        activeBlindnessTicks = tag.getInt("ActiveBlindnessTicks");
        bladeClock = tag.getInt("BladeClock");
        flightClock = tag.getInt("FlightClock");
    }

    public int getPhase() { return this.entityData.get(PHASE); }
    public boolean isFlying() { return this.entityData.get(FLYING); }
}
